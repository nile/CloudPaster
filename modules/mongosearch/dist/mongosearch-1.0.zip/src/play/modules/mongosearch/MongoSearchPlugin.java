package play.modules.mongosearch;

import play.PlayPlugin;
import play.exceptions.UnexpectedException;

public class MongoSearchPlugin extends PlayPlugin {
    
    @Override
	public void onApplicationStart() {
    	System.out.println("init");
        MongoSearch.init();
	}

	@Override
    public void onApplicationStop() {
        try {
        	MongoSearch.shutdown();
        } catch (Exception e) {
            throw new UnexpectedException (e);
        }
    }

    @Override
    public void onEvent(String message, Object context) {
        if (!message.startsWith("JPASupport")) 
            return;
        if (message.equals("JPASupport.objectPersisted") || message.equals("JPASupport.objectUpdated")) {
        	MongoSearch.index (context);
        } else if (message.equals("JPASupport.objectDeleted")) {
        	MongoSearch.unIndex(context);
        }
    }
}
